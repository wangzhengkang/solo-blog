title: JDK8之Lambda表达式
date: '2019-12-04 20:30:48'
updated: '2019-12-04 20:32:20'
tags: [Java, Lambda]
permalink: /articles/2019/12/04/1575462648402.html
---
# **1.Lambda表达式**

Java8最值得学习的特性就是Lambda表达式和Stream API，本文将粗略的介绍Lambda表达式；如果有函数式语言基础，对理解Lambda表达式有很大帮助，因为Java正在将自己变的更高（Sha）级（Gua），更人性化。--------可以这么说Lambda表达式其实就是实现SAM接口的语法糖。

Lambda表达式写的好可以极大的减少代码冗余，同时可读性也好过冗长的内部类，匿名类。

先列举两个常见的简化（简单的代码同样好理解）

* 创建线程

![](https://images2015.cnblogs.com/blog/383285/201609/383285-20160927202259281-168793735.jpg)

* 排序

![](https://images2015.cnblogs.com/blog/383285/201609/383285-20160927202314000-1168893403.jpg)

Lambda表达式配合Java8新特性Stream API可以将业务功能通过函数式编程简洁的实现。(为下期的例子做铺垫)

例如：

![](https://images2015.cnblogs.com/blog/383285/201609/383285-20160930132644125-1633466372.jpg)

这段代码就是对一个字符串的列表，把其中包含的每个字符串都转换成全小写的字符串。注意代码第四行的map方法调用，这里map方法就是接受了一个Lambda表达式。

## **1.1 Lambda表达式语法**

### **1.1.1 Lambda表达式的一般语法**

```
(Type1 param1, Type2 param2, ..., TypeN paramN) -> {
  statment1;
  statment2;
  //.............
  return statmentM;
}
```

这是Lambda表达式的完全式语法，后面几种语法是对它的简化。

### **1.1.2单参数语法**

```
param1 -> {
  statment1;
  statment2;
  //.............
  return statmentM;
}
```

当Lambda表达式的参数个数只有一个，可以省略小括号

例如：将列表中的字符串转换为全小写

```
List<String> proNames = Arrays.asList(new String[]{"Ni","Hao","Lambda"});  
List<String> lowercaseNames1 = proNames.stream().map(name -> {return name.toLowerCase();}).collect(Collectors.toList());
```

### **1.1.3单语句写法**

param1 -> statment

当Lambda表达式只包含一条语句时，可以省略**大括号、return和语句结尾的分号**

例如：将列表中的字符串转换为全小写

```
List<String> proNames = Arrays.asList(new String[]{"Ni","Hao","Lambda"});
List<String> lowercaseNames2 = proNames.stream().map(name -> name.toLowerCase()).collect(Collectors.toList()); 
```

### **1.1.4方法引用写法**

（方法引用和Lambda一样是Java8新语言特性，后面会讲到）

Class or instance :: method

例如：将列表中的字符串转换为全小写

List<String> proNames = Arrays.asList(new String[]{"Ni","Hao","Lambda"});

List<String> lowercaseNames3 = proNames.stream().map(String::toLowerCase).collect(Collectors.toList());

## 1.2lambda表达式可使用的变量

先举例：

//将为列表中的字符串添加前缀字符串  
```
	String waibu = "lambda :";  
	List<String> proStrs = Arrays.asList(new String[]{"Ni","Hao","Lambda"});  
	List<String>execStrs = proStrs.stream().map(chuandi -> {  
		Long zidingyi = System.currentTimeMillis();  
		return waibu + chuandi + " -----:" + zidingyi;  
	}).collect(Collectors.toList());  
	execStrs.forEach(System.out::println);
```

输出:

```
lambda :Ni -----:1575462251784
lambda :Hao -----:1575462258235
lambda :Lambda -----:1575462262785


 

变量waibu ：外部变量

变量chuandi ：传递变量

变量zidingyi ：内部自定义变量

 ```

Lambda表达式可以访问给它传递的变量，访问自己内部定义的变量，同时也能访问它外部的变量。

不过Lambda表达式访问外部变量有一个非常重要的限制：变量不可变（只是引用不可变，而不是真正的不可变）。

当在表达式内部修改waibu = waibu + " ";时，IDE就会提示你：

Local variable waibu defined in an enclosing scope must be final or effectively final

编译时会报错。因为变量waibu被lambda表达式引用，所以编译器会隐式的把其当成final来处理。

以前Java的匿名内部类在访问外部变量的时候，外部变量必须用final修饰。现在java8对这个限制做了优化，可以不用显示使用final修饰，但是编译器隐式当成final来处理。

## 1.3 Lambda表达式中的this概念

在Lambda中，this不是指向Lambda表达式产生的那个SAM对象，而是声明它的外部对象。

例如：

```
public class WhatThis {  
  
     public void whatThis(){  
           //转全小写  
           List<String> proStrs = Arrays.asList(new String[]{"Ni","Hao","Lambda"});  
           List<String> execStrs = proStrs.stream().map(str -> {  
                 System.out.println(this.getClass().getName());  
                 return str.toLowerCase();  
           }).collect(Collectors.toList());  
           execStrs.forEach(System.out::println);  
     }  
  
     public static void main(String[] args) {  
           WhatThis wt = new WhatThis();  
           wt.whatThis();  
     }  
}
```

输出：

```
com.wzk.test.WhatThis  
com.wzk.test.WhatThis  
com.wzk.test.WhatThis  
ni  
hao  
lambda
```

# 2.方法引用和构造器引用

本人认为是进一步简化Lambda表达式的声明的一种语法糖。

前面的例子中已有使用到： execStrs.forEach(System.out::println);

## 2.1方法引用

objectName::instanceMethod

ClassName::staticMethod

ClassName::instanceMethod

前两种方式类似，等同于把lambda表达式的参数直接当成instanceMethod|staticMethod的参数来调用。比如
System.out::println等同于x->System.out.println(x)；
Math::max等同于(x, y)->Math.max(x,y)。

最后一种方式，等同于把lambda表达式的第一个参数当成instanceMethod的目标对象，其他剩余参数当成该方法的参数。比如
String::toLowerCase等同于x->x.toLowerCase()。

可以这么理解，前两种是将传入对象当参数执行方法，后一种是调用传入对象的方法。

## 2.2构造器引用

构造器引用语法如下：
ClassName::new，把Lambda表达式的参数当成ClassName构造器的参数 。
例如 BigDecimal::new等同于x->new BigDecimal(x)。
