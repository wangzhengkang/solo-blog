title: tomcat日常
date: '2019-11-26 10:47:13'
updated: '2019-12-02 20:21:58'
tags: [Tomcat]
permalink: /articles/2019/11/26/1574736433502.html
---
操作步骤：


第一步：进入tomcat的bin目录


cd /usr/local/tomcat/bin
第二步：使用tomcat关闭命令




./shutdown.sh  
第三步：查看tomcat是否关闭




ps -ef|grep java  
如果显示以下信息，则说明没有关闭：


root      7010     1  0 Apr19 ?        00:30:13 /usr/local/java/bin/java -Djava.util.logging.config.file=/usr/local/tomcat/conf/logging.properties  


-Djava.awt.headless=true -Dfile.encoding=UTF-8 -server -Xms1024m -Xmx1024m -XX:NewSize=256m -XX:MaxNewSize=256m -XX:PermSize=256m -XX:MaxPermSize=256m -XX  


:+DisableExplicitGC -Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager -Djava.endorsed.dirs=/usr/local/tomcat/endorsed -classpath /usr/local/  


tomcat/bin/bootstrap.jar -Dcatalina.base=/usr/local/tomcat -Dcatalina.home=/usr/local/tomcat -Djava.io.tmpdir=/usr/local/tomcat/temp org.apache.catalina.start  


up.Bootstrap start  
如果想直接结束tomcat进程，可以使用kill命令




kill -9 7010  
基于查看tomcat是否关闭




ps -ef|grep java  
如果出现以下信息，则说明已经关闭


root      7010     1  0 Apr19 ?        00:30:30 [java] <defunct>  


第四步：启动tomcat




./startup.sh   


2：查看tomcat的日志


[root@localhost bin]# cd .. 
[root@localhost tomcat7.0]# ls 
bin   hsperfdata_root  LICENSE  NOTICE         RUNNING.txt  webapps
conf  lib              logs      RELEASE-NOTES  temp         work 
[root@localhost tomcat7.0]# cd logs  (打开日志文件夹)
[root@localhost logs]# ls 
catalina.2011-05-30.log      localhost.2011-06-28.log
catalina.out                 localhost_access_log.2011-06-27.txt
host-manager.2011-05-30.log  localhost_access_log.2011-07-07.txt 


[root@localhost logs]# tail -f catalina.out   （查看tomcat的日志文件）

tomcat也可以配置虚拟路径作为文件映射（配置server.xml host标签）

